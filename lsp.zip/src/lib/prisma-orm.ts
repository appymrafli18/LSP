import { PrismaClient } from "@prisma/client";

export const prisma_connection = new PrismaClient();
