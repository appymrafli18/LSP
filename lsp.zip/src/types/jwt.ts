export interface IPayload {
  id: number;
  username: string;
  name: string;
  email: string;
  role: string;
}