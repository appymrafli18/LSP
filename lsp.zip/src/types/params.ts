export interface IParams {
  uuid: string;
}