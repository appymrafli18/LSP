export interface FormFieldProps {
  name: string;
  label: string;
  required?: boolean;
}