import LandingMyTickets from "@/components/landing-page/LandingMyTickets";
import React from "react";

const Page = () => {
  return <LandingMyTickets />;
};

export default Page;
