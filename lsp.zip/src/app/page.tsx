import Landing from "@/components/landing-page/Landing";

export default function Home() {
  return <Landing />;
}
